module.exports = {
    entry: {
        app: "./index.js"
    },

    module: {
        rules: [{}]
    },

    plugins: [],

    output: {
        filename: "app.js",
        path: "./build"
    }
};